import paho.mqtt.client as mqtt
import json
import time
import random


MQTT_BROKER = "mosquitto"
MQTT_PORT = 1883


class MQTTClient:
    def __init__(self, broker, port):
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.connect(broker, port, 60)

    def on_connect(self, client, userdata, flags, rc):
        print(f"Connected to MQTT broker with code {rc}")

    def publish(self, topic, payload):
        self.client.publish(topic, json.dumps(payload))

    def loop(self):
        self.client.loop_start()

class VerkeerslichtActuator:
    def __init__(self, actuator_id, begin_status="groen"):
        self.actuator_id = actuator_id
        self.status = begin_status

    def rood(self):
        self.status = "rood"
    def groen(self):
        self.status = "groen"


class SnelheidsSensor:
    def __init__(self, sensor_id, snelheidslimiet=123):
        self.sensor_id = sensor_id
        self.snelheidslimiet = snelheidslimiet

    def measure(self):
        ruis=random.uniform(-10, 10)
        return max(0,self.snelheidslimiet + int(ruis))
    def update_limiet(self, delta):
        self.snelheidslimiet = max(0.0, min(100.0, self.snelheidslimiet + delta))



    def genereer_nummerplaat(self):
       
        if random.choice([True, False]): 
            # BE-wagens
            nummerplaat = f"{random.randint(1, 2)}-{''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=3))}-{random.randint(100, 999)}"
        else:
            # NL-wagens
            nummerplaat = f"{''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=2))}-{random.randint(100, 999)}-{''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=2))}"

        return nummerplaat

class FlitserSensor:
    def __init__(self, sensor_id,initial_flits=0):
        self.sensor_id = sensor_id
        self.flitser = initial_flits

    def measure(self):
        self.flitser += 1
        return self.flitser

class Verkeerslicht:
    def __init__(self, verkeerslicht, snelheidssensor, flitser):
        self.verkeerslicht = verkeerslicht
        self.snelheidssensor = snelheidssensor
        self.flitser = flitser
        self.rood_timer = 0

class Verkeerslicht:
    def __init__(self, verkeerslicht, snelheidssensor, flitser):
        self.verkeerslicht = verkeerslicht
        self.snelheidssensor = snelheidssensor
        self.flitser = flitser
        self.rood_timer = 0
        self.groen_timer = 0

    def proces(self):
        # Traffic light logic
        if self.verkeerslicht.status == 'rood':
            self.rood_timer += 1
            if self.rood_timer >= 5:  # Wacht 5 cycli
                self.verkeerslicht.groen()
                self.rood_timer = 0
                self.groen_timer = 0
        else:  # Als  het licht groen is
            self.groen_timer += 1
            if self.groen_timer >= 10 or random.random() < 0.2:  # 20% kans per cyclus of na 10 cycli
                self.verkeerslicht.rood()
                self.groen_timer = 0

        snelheid = self.snelheidssensor.measure()
        nummerplaat = self.snelheidssensor.genereer_nummerplaat()

        print(f"Verkeerslicht status: {self.verkeerslicht.status}")
        print(f"Gemeten snelheid: {snelheid:.0f} km/h | Nummerplaat: {nummerplaat}")

        fout_type = None
        if self.verkeerslicht.status == "rood" and random.random() < 0.1:  # 10% kans om door rood te rijden
            fout_type = "Rood licht"
        if snelheid > self.snelheidssensor.snelheidslimiet:
            if fout_type:  
                fout_type = "Rood licht en snelheidsovertreding"
            else:
                fout_type = "Snelheidsovertreding"

        if fout_type:
            print(f"Flits! {fout_type} gedetecteerd voor nummerplaat {nummerplaat}.")
            self.flitser.flitser += 1

        print(f"Totaal aantal wagens: {self.flitser.flitser}")

 
def simulation_loop():
    snelheidssensor = SnelheidsSensor(sensor_id="snelheidssensor_01", snelheidslimiet=120)
    verkeerslicht = VerkeerslichtActuator(actuator_id="verkeerslicht_01", begin_status="groen")
    flitser = FlitserSensor(sensor_id="flitser_01",initial_flits=0)

    meting = Verkeerslicht(verkeerslicht, snelheidssensor, flitser)

    mqtt_client = MQTTClient(MQTT_BROKER, MQTT_PORT)
    mqtt_client.loop()

    while True:
        site = "site1"

        # Update proces
        meting.proces()

        # Publish sensor data
        mqtt_client.publish(f"factory/{site}/sensor/{snelheidssensor.sensor_id}/snelheidslimiet", {
            "value": snelheidssensor.measure(),  # Aanroep van de methode
            "unit": "km/u",
        })

        mqtt_client.publish(f"factory/{site}/sensor/{flitser.sensor_id}/flitser", {
            "value": flitser.measure(),  # Correcte methode voor flitsen
        })

        # Publish actuator status
        mqtt_client.publish(f"factory/{site}/actuator/{verkeerslicht.actuator_id}/status", {
            "state": verkeerslicht.status,  # Gebruik de getter voor status
        })

        time.sleep(1)

if __name__ == "__main__":
    simulation_loop()
